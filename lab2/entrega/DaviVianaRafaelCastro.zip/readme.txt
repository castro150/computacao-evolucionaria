Integrantes do grupo:
Davi Pinheiro Viana
Rafael Carneiro de Castro

Para executar basta executar 

$ lab2(pop_size, n_int)

Em que pop_size eh o tamanho de populacao a ser utilizado e n_int eh o numero maximo de iteracoes do algoritmo