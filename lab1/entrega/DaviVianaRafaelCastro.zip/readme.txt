Integrantes do grupo:
Davi Pinheiro Viana - 2013029912
Rafael Carneiro de Castro - 

Para executar basta executar 

$ lab1(N, pop_size)

Em que N eh o numero de rainhas e pop_size eh o tamanho de populacao a ser utilizado