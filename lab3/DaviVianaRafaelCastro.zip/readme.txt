Integrantes do grupo
Davi Pinheiro Viana
Rafael Carneiro de Castro

Para executar basta rodar no MatLAB os comandos: 

$ lab3_peaks

OU

$ lab3_rastrigin